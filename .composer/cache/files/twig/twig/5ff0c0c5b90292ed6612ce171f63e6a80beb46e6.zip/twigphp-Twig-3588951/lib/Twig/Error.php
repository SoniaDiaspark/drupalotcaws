<?php

use Twig\Error\Error;

class_exists('Twig\Error\Error');

if (\false) {
    class Twig_Error extends Error
    {
    }
}
