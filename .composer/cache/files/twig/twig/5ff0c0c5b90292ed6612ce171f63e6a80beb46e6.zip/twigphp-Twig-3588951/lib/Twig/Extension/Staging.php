<?php

use Twig\Extension\StagingExtension;

class_exists('Twig\Extension\StagingExtension');

if (\false) {
    class Twig_Extension_Staging extends StagingExtension
    {
    }
}
