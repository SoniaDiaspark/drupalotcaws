<?php

use Twig\TokenParser\TokenParserInterface;

class_exists('Twig\TokenParser\TokenParserInterface');

if (\false) {
    class Twig_TokenParserInterface extends TokenParserInterface
    {
    }
}
