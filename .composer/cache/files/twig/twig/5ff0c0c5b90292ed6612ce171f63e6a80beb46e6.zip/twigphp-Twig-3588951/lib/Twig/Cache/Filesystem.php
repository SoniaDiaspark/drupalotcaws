<?php

use Twig\Cache\FilesystemCache;

class_exists('Twig\Cache\FilesystemCache');

if (\false) {
    class Twig_Cache_Filesystem extends FilesystemCache
    {
    }
}
