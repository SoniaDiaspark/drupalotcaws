<?php

use Twig\Parser;

class_exists('Twig\Parser');

if (\false) {
    class Twig_Parser extends Parser
    {
    }
}
