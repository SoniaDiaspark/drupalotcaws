<?php

use Twig\RuntimeLoader\ContainerRuntimeLoader;

class_exists('Twig\RuntimeLoader\ContainerRuntimeLoader');

if (\false) {
    class Twig_ContainerRuntimeLoader extends ContainerRuntimeLoader
    {
    }
}
