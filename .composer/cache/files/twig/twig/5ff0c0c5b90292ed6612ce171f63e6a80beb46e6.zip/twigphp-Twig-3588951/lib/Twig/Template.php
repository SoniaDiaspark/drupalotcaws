<?php

use Twig\Template;

class_exists('Twig\Template');

if (\false) {
    class Twig_Template extends Template
    {
    }
}
