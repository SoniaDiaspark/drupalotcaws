<?php

use Twig\NodeVisitor\NodeVisitorInterface;

class_exists('Twig\NodeVisitor\NodeVisitorInterface');

if (\false) {
    class Twig_NodeVisitorInterface extends NodeVisitorInterface
    {
    }
}
