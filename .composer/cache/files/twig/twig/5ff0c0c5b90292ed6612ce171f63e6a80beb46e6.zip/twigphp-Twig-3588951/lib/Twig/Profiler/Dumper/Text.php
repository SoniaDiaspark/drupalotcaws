<?php

use Twig\Profiler\Dumper\TextDumper;

class_exists('Twig\Profiler\Dumper\TextDumper');

if (\false) {
    class Twig_Profiler_Dumper_Text extends TextDumper
    {
    }
}
