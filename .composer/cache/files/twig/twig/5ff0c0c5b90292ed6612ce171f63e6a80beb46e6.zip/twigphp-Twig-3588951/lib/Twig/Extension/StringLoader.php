<?php

use Twig\Extension\StringLoaderExtension;

class_exists('Twig\Extension\StringLoaderExtension');

if (\false) {
    class Twig_Extension_StringLoader extends StringLoaderExtension
    {
    }
}
