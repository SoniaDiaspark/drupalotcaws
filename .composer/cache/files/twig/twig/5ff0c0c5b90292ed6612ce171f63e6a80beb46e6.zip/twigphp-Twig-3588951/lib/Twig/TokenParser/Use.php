<?php

use Twig\TokenParser\UseTokenParser;

class_exists('Twig\TokenParser\UseTokenParser');

if (\false) {
    class Twig_TokenParser_Use extends UseTokenParser
    {
    }
}
