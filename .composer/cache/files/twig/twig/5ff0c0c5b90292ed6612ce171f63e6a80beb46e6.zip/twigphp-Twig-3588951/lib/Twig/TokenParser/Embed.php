<?php

use Twig\TokenParser\EmbedTokenParser;

class_exists('Twig\TokenParser\EmbedTokenParser');

if (\false) {
    class Twig_TokenParser_Embed extends EmbedTokenParser
    {
    }
}
