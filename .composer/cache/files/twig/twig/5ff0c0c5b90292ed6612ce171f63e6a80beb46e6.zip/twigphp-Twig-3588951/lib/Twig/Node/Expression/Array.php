<?php

use Twig\Node\Expression\ArrayExpression;

class_exists('Twig\Node\Expression\ArrayExpression');

if (\false) {
    class Twig_Node_Expression_Array extends ArrayExpression
    {
    }
}
