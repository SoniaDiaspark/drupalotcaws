<?php

namespace Consolidation\SiteProcess;

interface CommandTesterInterface
{
    const STATUS_OK = 0;
    const STATUS_ERROR = 1;
}
