<?php

// The search scripts shouldn't find me as I do not match the patterns.
