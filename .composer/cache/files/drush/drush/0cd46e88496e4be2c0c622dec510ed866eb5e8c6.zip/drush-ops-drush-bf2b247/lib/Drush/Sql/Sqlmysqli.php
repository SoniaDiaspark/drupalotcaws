<?php

namespace Drush\Sql;

class Sqlmysqli extends Sqlmysql {

}